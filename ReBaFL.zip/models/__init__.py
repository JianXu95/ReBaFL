from .resnet import *
from .cnn import *
from .mlp import *
from .linear_regression import *